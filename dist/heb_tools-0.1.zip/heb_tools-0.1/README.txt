The project processes raw Datawell Waverider (http://www.datawell.nl) 
files into a flexible time series. The code allows easier calculation of 
statistics from the displacment data, more sophisticated masking of improbable
data and the ability to deal with larger timeseries than is available from 
existing software. Similar code is also used to process pressure data from 
Nortek AWAC (http://www.nortek-as.com/en/products/wave-systems/awac)
sensors details are described below.

In the case of a Datawell Waverider buoy the data directory containing year 
subfolders must be supplied to the main **raw_combined.py** module. The class 
Load_Raw_Files then iterates through the years. Processing the records 
from the raw files into a pandas DataFrame for each month with columns 
'sig_qual', 'heave', 'north' and 'west' the index being a pandas 
DateTimeIndex. An optional year parameter can be supplied to process a specifc
year folder.

The code skips empty or erroneously long files and each record is rounded to 
the nearest tenth of a second, so the sequence is slightly irregular. Caution 
should be taken in treating the timestamps as absolute values, they are a best 
approximation in the context of the time series. The first value in every raw 
file is treated as the very start of that half hour period, e.g. for the file 
Buoy_Name}2011-12-05T18h30Z.raw  the first record will have a timestamp of 
18:30:00 ( Hours:Minutes:Seconds ).  

Peak and troughs are detected for the heave values in the **extrema.py** module
then masking is applied to data that has quality issues in the 
error_check.py module. In the wave_stats.py module wave heights and 
zero crossing periods are calculated, wave heights are calculated from peak to 
trough.

problem_file_concat.py module produces a csv file with the filenames of 
all raw files that could not be processed, this module can be run after 
raw_combined.py.

wave_concat.py module can be run after raw_combined.py to create a 
complete dataframe of all wave heights timestamped and sorted temporally for 
each buoy. Statistics are then generated on wave sets derived from the complete
dataframe which are then exported as an Excel workbook ( .xlsx file ). This 
module requires a directory path that contains buoy directories and their 
names, the set size used for statistic calculation can be by number of waves or
time interval.

In the awac folder there is a wad_to_dataframe.py module than can 
process a Nortek AWAC wad file. The pressure column can be then be processed in
the same way as the Waverider heave displacement without the error correction. 
There is an awac_stats.py module which uses an approach similar to 
wave_concat.py for calculating time interval based statistics.

test_raw_combined.py is a module for testing the Load\_Raw\_Files and 
Wave_Stats classes, example buoy data is required to test, 1 month of 
anonymised data is provided in buoy_data.zip

The project was developed with data received from Waverider MKII and MKIII 
buoys with RFBuoy v2.1.27 producing the raw files. The AWAC was a 1MHz device
and Storm v1.14 produced the wad files. The code was developed with the 
assistance of the Hebridean Marine Energy Futures (http://hebmarine.com) 
project.

Requires: 

- [Python 2.7](http://python.org/download/) ( developed and tested with 2.7.3 )
- [Numpy](http://numpy.scipy.org) ( developed and tested with 1.6.2 )
- [Pandas](http://pandas.pydata.org) ( minimum 0.10.1 )
- [Matplotlib](http://matplotlib.org) ( developed and tested with 1.2.0 )
- [openpyxl](http://bitbucket.org/ericgazoni/openpyxl/src) ( developed and tested with 1.6.1 )

Almost all of the above requirements can be satisfied with a Python 
distribution like Anaconda CE (http://continuum.io/downloads.html).

openpyxl can be installed afterwards by running 'easy_install openpyxl' from 
the Anaconda scripts directory. Test.