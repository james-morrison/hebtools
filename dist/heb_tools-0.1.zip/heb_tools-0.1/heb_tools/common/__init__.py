from wave_stats import WaveStats
from extrema import GetExtrema